   /* Get the HTTP page */
libname Web "C:\UntangledWeb\SASData";
filename LocalCpy "C:\UntangledWeb\Downloads\sas_products.html";
/*proc http */
/*   url='http://www.sas.com/products/index.html'*/
/*   out=LocalCpy method="get"*/
/*   ;*/
/*run;*/

   /* Parsing with PRX functions */
data Web.SAS_Products_PRX;
   drop _:; 
   length Product $50 Link $1024;
   retain _RXTop _RXBot _RXData;
   if _n_=1 then do;
      _RXTop=PRXPARSE('!<a name="[a-w]"><b>[a-w]</b></a><br>!i');
      _RXData=PRXPARSE('!<a href="(/(?:[\w\-\.\%\#]+/*)+)" class="rtnavprodsol">([\w\s\.\-]+)</a><br>!i');
      _RXBot=PRXPARSE("/<!-- SECTION BREAK -->/i");
   end;
   infile LocalCpy lrecl=32767 end=_end;
   /* Find the top of a data list */
   do until (_Found or _end);
     input;
      _Found=PRXMATCH(_RXTop,_infile_);
   end;
   /* Read data until @ bottom of the data list */
   do until (_Found or _end);
     input;
      _Found=PRXMATCH(_RXBot,_infile_);
     if _found then leave;
      _DataMatch=PRXMATCH(_RXData,_infile_);
     if _DataMatch then do;
         Link=prxposn(_RXData,1,_infile_);
       Link=CAT('http://www.sas.com',Link);
         Product=prxposn(_RXData,2,_infile_);
        output;
      end;
   end;
run;

proc sql number;
title "SAS Products & Links using PRX Functions";
select *
   from Web.sas_products_prx
;
quit;
