libname kiva "C:\UntangledWeb\SASData\Kiva";
proc sql;
create table loan as
select distinct input(funded_amount,comma16.) as Funded
              , input(paid_amount,comma16.) as Paid
      , activity, sector, use 
      , input(scan(funded_date,1),4.) as Year
   from kiva.loan 
   where calculated year=2006
;
title "Kiva Loans in 2006";
select year, sum(funded) format=dollar16. as funded
	 , count(*) format=comma12. as Loans
     , sum(Paid) format=dollar16. as paid
 	 , (calculated funded-calculated paid)/calculated funded format=percent5.1 as Losses
   from loan
   group by year
;
title "Kiva Lenders by Country";
select country_code label="" as Country
	 , count(*) format=comma12. as Lenders
   from kiva.lender
   group by 1
   having country ne "" and Lenders >25
   order by Lenders desc, 1
;
quit;
 

