options noxwait;
data _null_;
   length winCommand $ 1024;
   winCommand=cat('powershell Invoke-WebRequest -Uri '
                 ,'"http://localhost/free_data/donors.zip" '
                 ,'-OutFile "C:\UntangledWeb\Downloads\donors.zip"');
   put winCommand=;
   call system(winCommand);
/*    Wait for the download to complete */
   do until (FILEEXIST("&path\Downloads\donors.zip"));
   end;
run;
