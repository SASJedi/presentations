FILENAME MyZIP zip "&path/Downloads/donors.zip";

data WORK.Donors_zip;
   infile MyZip(donors.txt) delimiter='09'x MISSOVER DSD firstobs=2;
   input Employee_ID Employee_Name:$25. Street_Number
         Street_Name:$20. City:$15. State:$2. Postal_Code
         Country:$2. Qtr1:comma. Qtr2:comma. Qtr3:comma. 
         Qtr4:comma. AnnualDonation:comma. Recipients:$75.;
   format Qtr1-Qtr4 AnnualDonation comma12.;
run;
filename MyZip;

proc FedSQL;
title "Imported from ZIP file member donors.txt";
select  Country, Employee_Name , AnnualDonation, Recipients 
   from Work.Donors_zip
   limit 10
;
quit;

