  /* That didn't work.  Let's download first: */
data _null_;
   /* Create the FTP Script file*/
   file "C:\UntangledWeb\Downloads\script.ftp";
   /* All the commands, just as I would type them interactively */
   PUT "anonymous"; /* FTP User ID */
   PUT "mark.jordan@sas.com"; /* FTP Password */
   PUT "binary"; /* Transport mode */
   PUT "prompt n"; /* Turn off prompting */
   PUT "cd free_data"; /* Change to FTP dir containing file */
   PUT "lcd C:\UntangledWeb\Downloads"; /* Change local dir - to 'catch' file */
   PUT "get donors.xlsx"; /* get the file */
   PUT "bye"; /* Disconnect */
run;

option noxwait;
data _null_;
   /* Download the Excel file */
   winCommand="FTP -v -s:C:\UntangledWeb\Downloads\script.ftp ftp.mystuff.com";
   call system(winCommand);
   /* Wait up to 30 seconds for the download to complete */
   do _i=1 to 30 until (_Complete);
      _Complete=FILEEXIST("C:\UntangledWeb\Downloads\donors.xlsx");
      if _Complete then do;
         PUTLOG "NOTE: File downloaded successfully in " _i " seconds.";
        leave;
     end;
      else call sleep(1,1);
   end;
   /* Clean up - delete the FTP Script file*/
   rc=filename("Script","C:\UntangledWeb\Downloads\script.ftp");
   if fexist("Script") then rc=fdelete("Script");
   msg=sysmsg();
   put msg;
   rc=filename("Script");
run;

proc import datafile="C:\UntangledWeb\Downloads\donors.xlsx"
            out=WORK.Donors_xls
            dbms=XLSX replace;
run;

proc FedSQL number;
title "Imported from Excel after FTP Download (5 rows)";
select  *
   from WORK.Donors_xls
   limit 5;
quit;
title;
