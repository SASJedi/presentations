options mcompilenote=all mprint;
%macro KivaImport(XMLFile=1.xml,XMLMap=KivaLoans.map
                 ,XMLPath=C:\UntangledWeb\Downloads\loans
                 ,codepath=C:\UntangledWeb\Code\KivaLoans_mod.sas);
proc datasets library=work kill nolist; quit;
%INCLUDE "&codepath" /source2 ;
%mend KivaImport;
/*************
%KivaImport()
%KivaImport(XMLFile=2.xml
           ,XMLMap=KivaLenders.map
           ,XMLPath=C:\UntangledWeb\Downloads\lenders
           ,codepath=C:\UntangledWeb\Code\KivaLenders_mod.sas)
**************/
