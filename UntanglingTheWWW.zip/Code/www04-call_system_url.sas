options noxwait;
data _null_;
   length winCommand $ 1024;
   winCommand=cat('powershell Start-BitsTransfer'
               ,' -Source http://mydemo.sas.com/free_data/donors.xlsx'
               ,' -Destination C:\UntangledWeb\Downloads\donors_http.xlsx');
   call system(winCommand);
   /* Wait up to 30 seconds for the download to complete */
   _starttime=time();
   do until (FILEEXIST("C:\UntangledWeb\Downloads\donors_http.xlsx"));
   end;
run;

proc import datafile="C:\UntangledWeb\Downloads\donors_http.xlsx"
            out=Work.Donors_xls_url
            dbms=xlsx replace;
run;

proc FedSQL number;
title "Imported from EXCEL downloaded via HTTP";
select  *
   from Work.Donors_xls_url
   limit 5;
quit;
title;
       
