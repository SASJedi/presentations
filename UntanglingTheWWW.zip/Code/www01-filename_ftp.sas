  /* Let's get read a CSV file in place */
filename MyFTP ftp "donors.csv" 
         host="ftp.mystuff.com" 
         user="anonymous"  pass="mark.jordan@sas.com" 
         cd="/free_data"
         debug;

proc import datafile=MyFTP out=WORK.Donors_csv 
            dbms=dlm replace;
   delimiter=",";
   getnames=yes;
run;

proc FedSQL;
title "&SYSLAST";
title2 "Imported from CSV using FILENAME FTP and DATA step";
select  *
   from WORK.Donors_csv limit 5;
quit;

  /* Now, let's try an EXCEL file */
filename MyFTP ftp 'donors.xlsx' cd='/free_data'
         user="anonymous"  pass="mark.jordan@sas.com" 
         host="mydemo.sas.com" debug;

proc import datafile=MyFTP out=WORK.Donors_xls
            dbms=excel replace;
run;
filename myftp;
