proc Sql;
create table work.orders as
   select *
   from Web.orders
;
reset outobs=5;
title "Before Standardization";
select CustomerID, ProductName
   from work.orders
   where prxmatch("!wo?m[ae]?n'?s!i", ProductName)
;
quit;

data work.orders;
   retain _RX1;
   drop _RX1;
   modify work.orders;
   if _n_=1 then do;
      _RX1=PRXPARSE("s/wo?m[ae]?n'?s/Woman's/i");
   end;
   call prxchange(_RX1,-1,ProductName);
run;

proc sql outobs=5;
title "After Standardization with CALL PRXCHANGE";
select CustomerID, ProductName
   from work.orders
   where prxmatch("!wo?m[ae]?n'?s!i", ProductName)
;
quit;
