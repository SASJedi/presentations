options mcompilenote=all mprint nosymbolgen nomlogic;
%macro GetLocaleInfo(url,loc, FinalData=work.TrainingSiteInfo);
filename LocalCpy "%qsysfunc(pathname(work))\training_site.html";
proc http url="%superq(url)"
   out=LocalCpy method="get";
run;
data GetLocaleInfo;
   length Location $2 StartDate EndDate 8  CourseName $100 CourseCode $4 InfoURL $150 _text $20;
   retain Location "%superq(Loc)" _RX:;
   format StartDate EndDate mmddyy10.;
   drop _:; 
   if _n_=1 then do;
      _RXTop=PRXPARSE('!<th class="addcarthead">Add to Cart</th></tr></thead>!i');
      _RXBot=PRXPARSE('!</table>!i');
      _RXURL=PRXPARSE('!<a href="(schedules\.html\?id=(\d{1,4}))!i');
   end;
   infile LocalCpy lrecl=32767 end=_NoMoreData truncover;
   do until (_Found or _NoMoreData);
     input;
      _Found=PRXMATCH(_RXTop,_infile_);
   end;
   do until (_Done or _NoMoreData);
     input;
      _Done=PRXMATCH(_RXBot,_infile_);
      if _done then leave;
      if PRXMATCH(_RXURL,_infile_) then do;
         CourseName=scan(_infile_,-2,'<>');
         CourseCode=PRXPOSN(_RXURL,2,_infile_);
         InfoURL=cats('https://support.sas.com/edu/',PRXPOSN(_RXURL,1,_infile_));
         input / /;
         _text=strip(compress(scan(_infile_,-2,'<>')));
         if lengthn(_text)<=9 then do;
            _TxtStart=_text;
            _TxtEnd=_text;
         end;
         else if lengthn(_text)<=12 then do;
            _TxtStart=cats(scan(_text,1),substr(_text,6));
            _TxtEnd=substr(_text,4);
         end;
         else do;
            _TxtStart=cats(scan(_text,1),substr(_text,12));
            _TxtEnd=scan(_text,-1);
         end;
         StartDate=input(_TxtStart,date9.);
         EndDate=input(_TxtEnd,date9.);
         output;
      end;
   end;
   stop;
run;
  /* Did we get any data? */
proc sql noprint;
select nlobs into:NumObs trimmed
   from dictionary.tables
   where LIBNAME='WORK'
     and MEMNAME='GETLOCALEINFO'
;
quit;

  /* If no data, so note in the log */
%if not &numobs %then %do;
%PUT WARNING: No schedule data for location %superq(Loc).;
%PUT WARNING- URL=%superq(url);
%end;
%else %do;
  /* Otherwise, append the data we retrieved to the final data file */
proc append base=&FinalData
            data=GetLocaleInfo;
run;
%end;
  /* Cleanup - put things back the way we found them */
proc sql; 
   drop table GetLocaleInfo; 
quit;
filename LocalCpy;
%mend;

  /* Test the macro */
/*%GetLocaleInfo(https://support.sas.com/edu/locations.html?locationId=ZZ&ctry=US,ZZ)*/
/*%GetLocaleInfo(https://support.sas.com/edu/locations.html?locationId=AR&ctry=US,AR)*/

/*title "GetLocaleInfo Macro Test";*/
/*proc FedSQL;*/
/*select * */
/*   from work.TrainingSiteInfo*/
/*   limit 5*/
/*;*/
/*drop table work.TrainingSiteInfo;*/
/*quit;*/
