  /* Include the previous macro code we built */
%include "C:\UntangledWeb\Code\www13-KivaImport.sas";

%macro KivaDriver(help
                 ,type=loans
                 ,lib=Kiva
                 ,libpath=C:\UntangledWeb\SASData\Kiva);
  /* Did I ask for help? */
%if %SUBSTR(&help,1,5)=!HELP %then %do;
   %PUT NOTE:  SYNTAX: %NRSTR(KivaDriver%(help,type=loans,lib=Kiva);
   %PUT NOTE:                    %NRSTR(libpath=C:\UntangledWeb\SASData\Kiva%));
   %PUT NOTE-          PARAMETERS:;
   %PUT NOTE-                type=loans or lenders;
   %PUT NOTE-                 lib=libref for permanent data storage;
   %PUT NOTE-             libpath=physical path to the permanent library;
   %return;
%end;
   %local fileref rc did dnum dmem memname didc;
   /* Open the specified directory */
   %let rc=%sysfunc(filename(fileref,C:\UntangledWeb\Downloads\&type));
   %let did=%sysfunc(dopen(&fileref));
   %if &did=0 %then 
   %do;
      %put ERROR: (KivaDriver) C:\UntangledWeb\Downloads\&type directory does not exist;
      %put ERROR-              The name was derived from the type= parameter(&type).;
      %put ERROR-              %NRSTR(%KivaDriver(!HELP)) for macro syntax;
      %return;
   %end;
   /* How many XML files are in the directory? */
   %let dnum=%sysfunc(dnum(&did));
   /* Import them all... */
   %do dmem=1 %to &dnum;
      /* Get the name of the next file */
      %let memname=%sysfunc(dread(&did,&dmem));
      %if %upcase(%scan(&memname,-1,.)) = XML %then
      %do;
         /* Call KivaImport to import the XML data */
         %KivaImport(XMLfile=&memname
                    ,XMLMap=Kiva&Type..map
                    ,XMLPath=C:\UntangledWeb\Downloads\&type
                    ,Codepath=C:\UntangledWeb\code\Kiva&type._mod.sas)
		 /* Append the imported data sets to permananet library */
       libname &lib "&libpath";
	   proc sql noprint;
		 /* How many datasets were built? */
       select count(*) into :count 
	      FROM DICTIONARY.TABLES
          WHERE LIBNAME="WORK"
       ;
         %let count=&count;
	     %if not &count %then 
         %do;
            quit;
	        %PUT WARNING: (KivaDriver)No data extracted from XML this run.;
            %let didc=%sysfunc(dclose(&did));
            %let rc=%sysfunc(filename(fileref));
		    %return;
         %end;
		 /* Build a series of PROC import steps (in macro variables) */
	   select CAT("PROC APPEND BASE=&lib..",STRIP(MEMNAME)
                  ," DATA=",MEMNAME,"; RUN;")
		  into :command1-:command&count
	      FROM DICTIONARY.TABLES
		  WHERE LIBNAME="WORK"
		  ;
      quit;
	     %do i=1 %to &count;
		 /* Resolve and execute the PROC import steps */
            &&Command&i;
         %end;
      %end;
   %end;
   /* Clean up */
   %let didc=%sysfunc(dclose(&did));
   %let rc=%sysfunc(filename(fileref));
%mend KivaDriver;
/*****************
proc datasets library=work nolist kill; quit;
proc datasets library=kiva nolist kill; quit;
%KivaDriver(type=loans,lib=Kiva,libpath=C:\UntangledWeb\SASData\Kiva)
%KivaDriver(type=lenders,lib=Kiva,libpath=C:\UntangledWeb\SASData\Kiva)
*****************/
