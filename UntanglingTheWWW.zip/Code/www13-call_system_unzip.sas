options noxwait;
data _null_;
   length winCommand $ 1024;
   winCommand=CAT("bitsadmin /transfer GetFile /download"
                 ," /priority normal "
                 ,"http://s3.kiva.org/snapshots/kiva_ds_xml.zip "
                 ,"C:\UntangledWeb\Downloads\Kiva.zip");
   call system(winCommand);
   /* Wait up to 30 seconds for the download to complete */
   do _i=1 to 30 until (_Complete);
      _Complete=FILEEXIST("C:\UntangledWeb\Downloads\Kiva.zip");
      if _Complete then do;
         PUTLOG "NOTE: File downloaded successfully in " _i " seconds.";
		  leave;
	  end;
      else call sleep(1,1);
   end;
   /* Then unzip the file */
   winCommand=CAT('"C:\Program Files (x86)\WinZip\wzunzip.exe"'
                 ,' -o -d ' 
                 ,'"C:\UntangledWeb\Downloads\KivaTest.zip" '
                 ,'"C:\UntangledWeb\Downloads"'
                 );
   call system(winCommand);
run;
