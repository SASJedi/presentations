proc Sql;
create table work.orders as
   select *
   from Web.orders
;
reset outobs=5;
title "Before Standardization";
select CustomerID, ProductName
   from work.orders
   where prxmatch("!wo?m[ae]?n'?s!i", ProductName)
;
quit;

proc SQL;
update work.orders
   set productName=prxchange("s/wo?m[ae]?n'?s/Woman's/i", -1, ProductName)
   where prxmatch("!wo?m[ae]?n'?s!i", ProductName)
;
reset outobs=5;
title "After Standardization";
select CustomerID, productName
   from work.orders
   where prxmatch("!wo?m[ae]?n'?s!i", ProductName)
;
quit;
