/* Get the HTTP page */
filename LocalCpy "&path/Downloads/us_training_locations.html";
proc http 
   url='https://support.sas.com/edu/country.html?ctry=us'
   out=LocalCpy method="get";
run;

/* Parsing with FIND, SCAN and _INFILE_ */
data web.SASTrainingLocations;
   drop _:;
   length Location $30 LocationCode $2 Link $70;
   infile LocalCpy lrecl=32700 end=eof;
   do until (_Top or EOF);
      input;
      _Top=find(_infile_,'<table class="crslst">');
      if _Top then do _i=1 to 10000; 
           if lowcase(scan(_infile_,_i,'<>')) = '/table' then leave;
            _thisText=scan(_infile_,_i,'<>');
            if find(_thisText,'href=') then do;
               Link=cats('https://support.sas.com/edu/',scan(_thisText,2,'"'));
               Location=scan(_infile_,_i+1,'<>');
               LocationCode=scan(Link,-3,'&=');
               output;
               _i=_i+1;
            end;
      end; 
   end;
run;
/*title "SAS Training Locations & Links using FIND and SCAN";*/
/*proc FedSQL;*/
/*select **/
/*   from web.SASTrainingLocations*/
/*   limit 5*/
/*;*/
/*quit;*/
/*title;*/
