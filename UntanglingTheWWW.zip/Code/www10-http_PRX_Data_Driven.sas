  /* Include the previous macro code we built */
%include "&path/Code/www08-http_PRX_GetInfo_Macro.sas";
%include "&path/Code/www09-http_PRX_GetInfo_Driver_Macro.sas";

  /* Make sure we start fresh... */
proc sql;
/*   drop table web.Sastraininglocations;*/
   drop table web.SASTrainingSchedules;
quit;


/* Grab the training location data */ 
%include "&path/Code/www05-http_parsing_scan.sas";

/* Using the training location data, get schedules for all locations */
%driver(Web.SASTrainingLocations,outlib=web)

/* Display some results */
proc SQL;
title "Randomly Selected Training Schedule Data";
select * 
   from web.SASTrainingSchedules
   where ranuni(1234) <.01
 ;
/*   drop table web.SASTrainingSchedules;*/
quit;
