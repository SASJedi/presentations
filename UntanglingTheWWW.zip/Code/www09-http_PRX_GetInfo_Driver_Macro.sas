%macro Driver(DSN,obs=max,outlib=WORK);
  /* Driver macro */
  /*****************************************************
   Because calling this macro is not an automated 
   process, do some parameter validation 
  *****************************************************/
  /* Did I forget to provide a data set name? */
%if &dsn=  %then %do;
   %PUT ERROR: (Driver) You must supply the name of a dataset.;
   %PUT NOTE:          SYNTAX: %NRSTR(%Driver(DSN,obs=max,outlib=work));
   %PUT NOTE:          where DSN=name of dataset containing Product and Link variables.;
   %PUT NOTE-                obs=number of observations to process from DSN.;
   %PUT NOTE-                outlib=LIBREF for outputting the data produced.;
   %return;
%end;
  /* Did I ask for help? */
%if %SUBSTR(&dsn,1,5)=!HELP %then %do;
   %PUT NOTE: (Driver) SYNTAX: %NRSTR(Driver(DSN,obs=max,outlib=work));
   %PUT NOTE-          where DSN=name of dataset containing Product and Link variables.;
   %PUT NOTE-                obs=number of observations to process from DSN.;
   %PUT NOTE-                outlib=LIBREF for outputting the data produced.;
   %return;
%end;
%let DSN=%upcase(&DSN);
  /* Is the data set name provided valid? */
%if not %sysfunc(exist(&DSN)) %then %do;
   %PUT ERROR: (Driver) Dataset &DSN does not exist.;
   %return;
%end;
  /*****************************************************
   Working code starts here:
   1.  Read the input dataset in SQL
   2.  Create a GetLocaleInfo macro call for each disctinct
       combination of URL and Loc
   3.  Execute the macro calls
  *****************************************************/
proc sql noprint;
select distinct cats('%GetLocaleInfo(',Link,',',LocationCode,",FinalData=&outlib..SASTrainingSchedules)")
   into :RunMyMacros separated by ' '
   from &dsn (obs=&obs)
;
quit;

&RunMyMacros
%mend;
