data ips;
	ipaddress = '172.217.3.46';
	output;
	ipaddress = '37.221.194.4';
	output;
	ipaddress = '95.14.110.142';
	output;
run;

option nonotes;
proc ds2;
	data ipgeo /overwrite=yes;
		dcl package http h();
		dcl varchar(100) country;
		dcl double lat lng;

		method run();
         dcl package json j();
         dcl varchar(2048) character set utf8 API_Response;
         dcl int rc tokenType parseFlags;
		 dcl nvarchar(128) token;

		 set ips;
         h.createGetMethod(cats('https://freegeoip.net/json/', ipaddress));
         h.executeMethod();
         h.getResponseBodyAsString(API_Response, rc);
		 
		 rc = j.createParser(API_Response );
		 do while (rc = 0);
        	j.getNextToken( rc, token, tokenType, parseFlags);

        	if token eq 'country_name' then do;
				j.getNextToken(rc, token, tokenType, parseFlags);
				country = token;
			end;
			else if token eq 'latitude' then do;
				j.getNextToken(rc, token, tokenType, parseFlags);
				lat = token;
			end;
			else if token eq 'longitude' then do;
				j.getNextToken(rc, token, tokenType, parseFlags);
				lng = token;
			end;

      	 end;
	
      	 output;
      	end;
	enddata;
	run;

quit;
options notes;
