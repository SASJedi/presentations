data _null_;
   length Buffer1 $1024 Buffer2 $50 infile $32000;
   infile datalines;
   input;
   _RXData=PRXPARSE('/<a href="(\/(?:[\w\-\.\%\#]+\/*)+)" class="rtnavprodsol">([\w\s\.\-]+)<\/a><br>/i');
   ItMatched=prxmatch(_RXData,_infile_);
   if ItMatched then do;
      Buffer1=prxposn(_RXData,1,_infile_);
      Buffer2=prxposn(_RXData,2,_infile_);
      putlog "NOTE: Record " _N_ " matched. " Buffer1= Buffer2=;
   end;
   else do;
      infile=_infile_;
      putlog "WARNING: Record " _n_ " didn't match. " ;
      putlog "WARNING- " infile= ;
   end;
datalines;
<a href="/industry/aerospace/" class="rtnavprodsol">Aerospace Solutions</a><br>
<a href="/solutions/abm/" class="rtnavprodsol">Activity-Based Management</a><br>
<a href="/industry/healthcare/insurer/actuarial-analysis.html" class="rtnavprodsol">Actuarial Analysis</a><br>
<a href="/technologies/bi/msoffice/index.html" class="rtnavprodsol">Add-in for Microsoft Office</a><br>
<a href="/technologies/analytics/advantage.html" class="rtnavprodsol">Analytic Advantage for Teradata</a><br>
<a href="/technologies/analytics/" class="rtnavprodsol">Analytics</a><br>
<a href="/technologies/analytics/statistics/analytics-pro/" class="rtnavprodsol">Analytics Pro</a><br>
<a href="/industry/fsi/aml/" class="rtnavprodsol">Anti-Money Laundering</a><br>
<a href="/technologies/bi/appdev/appdev/" class="rtnavprodsol">AppDev Studio</a><br>
<a href="/technologies/bi/appdev/" class="rtnavprodsol">Applications Development</a><br>
<a href="/technologies/architecture/" class="rtnavprodsol">Architecture</a><br>
<a href="/industry/auto/" class="rtnavprodsol">Automotive Solutions</a><br>
;
run;
