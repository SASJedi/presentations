  /* Using a Data Step */
filename OutFile "C:\UntangledWeb\Downloads\yahoo_data_sas.html";
filename httpIn url 'http://search.yahoo.com/search?p=sas+institute&toggle=1&cop=mss&ei=UTF-8&fr=yfp-t-701';

data _null_;
   infile httpIn lrecl=32700;
   file outfile;
   input;
   put _infile_;
run;

  /* Using PROC HTTP */
filename OutFile "C:\UntangledWeb\Downloads\yahoo_http_sas.html";
proc http 
   url='http://search.yahoo.com/search?p=sas+institute&toggle=1&cop=mss&ei=UTF-8&fr=yfp-t-701'
   out=OutFile method="get"
   ;
run;

  /* Using a web API and PROC HTTP */
filename OutFile "C:\UntangledWeb\Downloads\yahoo_api_sas.txt";
filename InFile "C:\UntangledWeb\Downloads\yahoo_api_query.txt";
data _null_;
   file InFile;
   put 'appid=restbook&query=sas+institute';
run;
proc http       
   out=outFile
   in=inFile
   url="http://api.search.yahoo.com/WebSearchService/V1/webSearch?" 
   method="post"      
   ct="application/x-www-form-urlencoded"
   ;
run;
