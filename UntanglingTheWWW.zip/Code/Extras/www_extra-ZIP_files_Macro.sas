%macro GetZipData(FileURL, LocalFolder,LocalFile,Wait,Parm);
%if (%NRBQUOTE(&FileURL)= AND not %index(L,%NRBQUOTE(&Parm))) 
    OR %NRBQUOTE(&LocalFolder)= 
    OR %NRBQUOTE(&LocalFile)=     %then %do;
   %PUT ERROR: (GetZipData) Specify the original ZIP file URL (or PARM of L), local file folder and local file name.;
   %PUT NOTE-  (GetZipData) %NRSTR(SYNTAX: %%GetZipData%(FileURL, LocalFolder, LocalFile<, Wait, Parm>%));
   %PUT NOTE-  (GetZipData) Example:;
   %PUT NOTE-  (GetZipData) %NRSTR(%%GetZipData%(http://www.abc.com/file.zip, C:\Temp, MyFile, 5%));
   %PUT NOTE-  (GetZipData) Downloads http://www.abc.com/file.zip to C:\Temp\MyFile.zip;
   %PUT NOTE-  (GetZipData)   and waits 5 seconds for the download to complete.;
   %PUT NOTE-  (GetZipData) Valid PARM values include:;
   %PUT NOTE-  (GetZipData)    L = Local ZIP already exists - do not download;
   %PUT NOTE-  (GetZipData)    G = Get zip file but do not process further.;
   %goto Exit;   
%end; 
%if %index(L,%NRBQUOTE(&Parm)) AND NOT %SYSFUNC(FILEEXIST(%nrbquote(&LocalFolder\&LocalFile..zip)))
  %then %do;
   %PUT ERROR: (GetZipData) Cannot UNZIP %nrbquote(&LocalFolder\&LocalFile..zip) - file does not exist.;
   %goto Exit;   
%end; 

%if wait= %then %let Wait=10;

data _null_; 
   length winCommand $ 10000;
   /* Delete local copy if older version exists */
   rc=filename("ZIPfile","%NRBQUOTE(&LocalFolder\&LocalFile.)zip)");
   if not rc and fexist("ZIPfile") then do;
       PUTLOG "NOTE: (GetZipData) Deleting existing local file." ;
       rc=fdelete("ZIPfile");
   end;
   rc=filename("ZIPfile");
%if NOT %index(L,%BQUOTE(&Parm)) %then %do;
   /* Download a fresh copy of the ZIP file */
   winCommand="bitsadmin /transfer GetZipFile /download /priority normal %NRBQUOTE(&FileURL) %NRBQUOTE(&LocalFolder\&LocalFile..zip)";
   call system(winCommand);
   /* Wait for the download to complete */
   do _i=1 to &wait until (_Complete);
      /* Wait in seconds */
      _Complete=FILEEXIST("%nrbquote(&LocalFolder\&LocalFile..zip)");
      if _Complete then do;
         PUTLOG "%NRBQUOTE(NOTE: &LocalFolder\&LocalFile..zip downloaded successfully.)";
		 PUTLOG "NOTE- Unzipping the file";
		 leave;
	  end;
      else call sleep(&Wait,1);
   end;
   if _I=11 then do;
      PUTLOG "%NRBQUOTE(ERROR: Timed out. Download of &FileURL unsuccessful.)";
	  STOP;
   end;
%end;
%if not %index(G,%NRBQUOTE(&Parm)) %then %do;
   /* Unzip the archive file */
   winCommand=CAT('"',"C:\Program Files (x86)\winzip\wzunzip.exe",'" -e -d -o "',"&LocalFolder\&LocalFile..zip",'" "',"&LocalFolder",'"');
   PUTLOG "NOTE: (GetZipData) Unzipping file by executing " wincommand ;
   call system(winCommand);
%end;
run;

%exit:
%mend;
options NOmprint NOmlogic;
%GetZipdata(%str(http://localhost/sasweb/HTTPDownloads/KivaTest.zip),%str(c:\temp),%str(Kiva),1,L)
%GetZipdata(,%str(c:\temp),%str(Kiva2),1,L)
%GetZipdata(,%str(c:\temp),%str(Kiva2),1)
%GetZipdata(%str(http://localhost/sasweb/HTTPDownloads/KivaTest.zip),,,1,G)
%GetZipdata(%str(http://localhost/sasweb/HTTPDownloads/KivaTest.zip),%str(c:\temp),%str(Kiva),1,L)
