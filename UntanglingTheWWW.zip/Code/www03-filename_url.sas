  /* Let's get read a CSV file in place */
filename MyURL URL "http://mydemo.sas.com/free_data/donors.csv"
        /*user="UserName" pass="myname@somewhere.com"*/;

proc import datafile=MyURL out=Work.Donors_csv_url
            dbms=dlm replace;
   delimiter=",";
   getnames=yes;
run;

proc FedSQL number;
title "Imported from CSV using FILENAME URL (5 obs)";
select  * 
   from Work.Donors_csv_url
   limit 5
;
quit;
title;

  /* Now, let's try an EXCEL file */
filename MyURL URL "http://mydemo.sas.com/free_data/donors.xlsx"
        /*user="UserName" pass="myname@somewhere.com"*/;

proc import datafile=MyURL 
            out=Work.Donors_xls_url
            dbms=excel replace;
run;
