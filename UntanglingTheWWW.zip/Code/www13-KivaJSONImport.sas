filename result "&path/Downloads/matt_demo.json";
proc http 
   url="http://api.kivaws.org/v1/lenders/matt.json" 
   out=result method="get";
run;
filename result;

libname kiva json "&path/Downloads/matt_demo.json";

proc contents data=kiva._all_ varnum; run;

title 'JSON Library - lender table';
proc print data=kiva.lenders; run;
title;

proc delete data=work.lenders;run;

proc append data=kiva.lenders(drop=ordinal:)
            base=work.lenders;
run;

title 'WORK library - lender data set';
proc print data=work.lenders; run;
title;
 

proc datasets library=work kill nolist; run; quit;
data lenders;
  input ident $;
datalines;
matt
jeremy
mark2693
;
%macro GetLenders;
proc sql noprint; 
select ident 
    into :id1-
    from lenders
;
quit;

%do i=1 %to &sqlobs;
filename result "&path/Downloads/&&id&i...json";
proc http 
   url="http://api.kivaws.org/v1/lenders/&&id&i...json" 
   out=result method="get";
run;
filename result;
%if &i =1 %then %do;
proc sql;
drop table WORK.LENDER_INFO;
create table WORK.LENDER_INFO
  (
   lender_id char(8),
   name char(25),
   whereabouts char(30),
   country_code char(2),
   uid char(8),
   member_since char(20),
   personal_url char(50),
   occupation char(25),
   loan_because char(100),
   occupational_info char(180),
   loan_count num,
   invitee_count num,
   inviter_id char(8)
  );
  quit;
%end;

libname kiva json "&path/Downloads/&&id&i...json";

proc append data=kiva.lenders(drop=ordinal:)
            base=work.lender_info force;
run;
libname kiva;
filename result;
%end;
%mend;

%GetLenders

proc sql;
title 'Kiva Lender Information';
select 
   name,
   whereabouts,
   country_code,
   occupation,
   loan_because,
   occupational_info,
   loan_count 
   from work.lender_info
;
quit;
title;
