libname WebData "C:\UntangledWeb\SASData";
  /* Base code before "macro-izing" */
filename LocalCpy "c:\UntangledWeb\Downloads\training_site.html";
/*proc http url='https://support.sas.com/edu/locations.html?locationId=AR&ctry=US'*/
/*   out=LocalCpy method="get";*/
/*run;*/
/* Test 1 */
data GetLocaleInfo;
   drop _:; 
   length CourseName $100 CourseCode InfoURL $150;
   retain _RX:;
   if _n_=1 then do;
      _RXTop=PRXPARSE('!<th class="addcarthead">Add to Cart</th></tr></thead>!i');
      _RXBot=PRXPARSE('!</table>!i');
      _RXURL=PRXPARSE('!<a href="(schedules\.html\?id=(\d{1,4}))!i');
   end;
   infile LocalCpy lrecl=32767 end=_NoMoreData truncover;
   do until (_Found or _NoMoreData);
     input;
      _Found=PRXMATCH(_RXTop,_infile_);
      if _Found then put _infile_;
   end;
   stop;
run;

/* Test 2 */
data GetLocaleInfo;
   drop _:; 
   length CourseName $100 CourseCode InfoURL $150;
   retain _RX:;
   if _n_=1 then do;
      _RXTop=PRXPARSE('!<th class="addcarthead">Add to Cart</th></tr></thead>!i');
      _RXBot=PRXPARSE('!</table>!i');
      _RXURL=PRXPARSE('!<a href="(schedules\.html\?id=(\d{1,4}))!i');
   end;
   infile LocalCpy lrecl=32767 end=_NoMoreData truncover;
   do until (_Found or _NoMoreData);
     input;
      _Found=PRXMATCH(_RXTop,_infile_);
   end;
   do until (_Done or _NoMoreData);
     input;
      _Done=PRXMATCH(_RXBot,_infile_);
      if _done then leave;
      if PRXMATCH(_RXURL,_infile_) then put _infile_;
   end;
   stop;
run;

/* Test 3 - the full code */

data GetLocaleInfo;
   drop _:; 
   length CourseName $100 CourseCode InfoURL $150;
   retain _RX:;
   if _n_=1 then do;
      _RXTop=PRXPARSE('!<th class="addcarthead">Add to Cart</th></tr></thead>!i');
      _RXBot=PRXPARSE('!</table>!i');
      _RXURL=PRXPARSE('!<a href="(schedules\.html\?id=(\d{1,4}))!i');
   end;
   infile LocalCpy lrecl=32767 end=_NoMoreData truncover;
   do until (_Found or _NoMoreData);
     input;
      _Found=PRXMATCH(_RXTop,_infile_);
   end;
   do until (_Done or _NoMoreData);
     input;
      _Done=PRXMATCH(_RXBot,_infile_);
      if _done then leave;
      if PRXMATCH(_RXURL,_infile_) then do;
         CourseName=scan(_infile_,-2,'<>');
         CourseCode=PRXPOSN(_RXURL,2,_infile_);
         InfoURL=cats('https://support.sas.com/edu/',PRXPOSN(_RXURL,1,_infile_));
         put CourseName= / CourseCode= / InfoURL= /;
      end;
   end;
   stop;
run;
