data womens not;
   retain _rxWomens;
   drop _:;
   input @;
   if _n_=1 then _rxWomens=prxparse("/wo?m[ea]?n'?s/i");
   input row word $;
   if prxmatch(_rxWomens,_infile_) then do;
      put _infile_;
      output womens;
   end;
   else output not;
datalines;
1 Woman
2 Woman's
3 Women's
4 Women
5 Wmns
6 Wns
7 Men's
8 womans
9 Man
10 womens
11 mens
12 mns
;
run;
title "Women's List";
proc print data=womens; 
run;
title "NOT Women's List";
proc print data=not; 
run;
title;
