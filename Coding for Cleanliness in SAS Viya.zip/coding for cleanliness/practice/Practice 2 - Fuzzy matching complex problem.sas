/*****************************************************************
 Setup & exploration:
 Run this code and review results and log
*****************************************************************/
/* Sample the Data */
proc SQL number;
	title "Customers";
	select Name,Street1,City, State from sasdq.Customers(obs=10);
	title "Cat Lovers Mailing List";
	footnote "Lines 1, 5, and 10 look suspiciously like cat names...";
	select Name,Address,City, State from sasdq.CatLovers (obs=10);
quit;
title;footnote;

title "Customers Who Are Also Cat Lovers";
proc sql number;
select Cat.Name as CatLoverName
      ,Cust.Name as CustName
      ,cat.Address as CatLoverStreet
      ,cust.Street1 as CustStreet
      ,cat.City as CatLoverCity
      ,cust.City as CustCity 
      ,Cat.State as CatLoverState
      ,Cust.State as CustState
      ,Cat.Zip as CatLoverZip
      ,Cust.Zip as CustZip
	from sasdq.Customers as cust
	   inner join 
    	 sasdq.CatLovers as cat
	on upcase(substr(cat.Address,1,10))=upcase(substr(cust.Street1,1,10))
	   and upcase(cat.City)=upcase(cust.City)
       and upcase(cat.State)=upcase(cust.State)
	   and cat.Zip=cust.Zip
;
quit;
title;

/*****************************************************************
 Solve the problem:
 Surely, more than 3 of our customers are cat lovers! 
*****************************************************************/

/*****************************************************************
 Step 1: What match definitions are available in the ENUSA locale?
*****************************************************************/
data _null_;
	num=dqLocaleInfoList('match', 'ENUSA');
run;

/*****************************************************************
 Step 2: 
 Because some of the mailing list names are cat names, we will  
 concatenate the address fields, generate match codes using the
 'City - State/Province - Postal Code' definition to find matches,
 and base our join criteria on the match codes.
 Modify the "Customers Who Are Also Cat Lovers" report to join 
 based on those match codes.
***************************************/*****************************************************************
 Step 5: 
 Run the solicitation mailing list report step below. Review the 
 report and answer the question.

*****************************************************************/

title "Solicitation Mailing List";
proc sql number;
select * 
    from SolicitationMailingList
    order by Name
;   
quit;
title;

/*****************************************************************
 Question: 
 Which row numbers appear to have subscription in the cat's name
 instead of the cat owner's?  

 Answer:
  
*****************************************************************/
