/***************************************************************** 
 Step 6:
 Run this code, the look at the log. 
 Is QKB CI 33 available for this session? 
*****************************************************************/
PROC QKB; 
	LIST;
run;

/***************************************************************** 
 Step 7:
 Run this code, the look at the log. 
 What is the default locale for this session? 
*****************************************************************/
proc options group=dataquality;
run;

