/* Setup for Working with Database Tables in SAS Viya*/
%let PATH=/home/student/win_share/wwdv4;
%let userID=student;
%let password=Metadata0;
libname mysas "&path/data";
libname myDB mysql server="server.demo.sas.com" port=3306 
			database=wwdv4 connection=global
			user="&userID" password="&password";

/* Start a CAS session */
cas conn;
/* Establish path-based caslib, assign LIBREF for easy viewing */
caslib mycas path="&path/data" libref=myCAS desc="Path-based caslib" ;
/* Establish caslibs, assign LIBREFs for easy viewing */
caslib myCASDB desc="MySQL caslib" 
     dataSource=(srctype='mysql'
                 host='server.demo.sas.com'
				 port=3306
                 username="&UserID"
                 password="&Password"
                 database="wwdv4")
                ) libref=myCASDB 
      ;
/* cas conn terminate; */