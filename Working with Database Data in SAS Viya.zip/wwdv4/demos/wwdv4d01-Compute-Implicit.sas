/* A quick introduction to implicit pass-through */
options sastrace=',,,d' sastraceloc=saslog nostsuffix;
Title "PROC PRINT results - Implicit Pass-through";
Title2 "Trucks not built in the USA";
proc print data=mydb.Cars;
	var Origin Type MSRP;
	where Type='Truck' and Origin <> 'USA';
run;

Title "PROC FREQ results - Implicit Pass-through";
Title2 "Type of vehicle by origin";
proc freq data=mydb.Cars;
	tables Type*Origin /nopercent nocol norow;
run;

Title "PROC MEANS results - Implicit Pass-through";
Title2 "Highway mileage by origin";
proc means data=mydb.Cars;
	class origin;
	var MPG_Highway;
run;

Title "PROC SQL results - Implicit Pass-through";
Title2 "Number of models by origin";
proc sql;
select Origin, count(*) as Models
	from mydb.Cars
	group by Origin
	order by 2 desc, 1
;
quit;

Title "PROC FedSQL results - Implicit Pass-through";
Title2 "Number of models by origin";
proc FedSQL;
select Origin, count(*) as Models
	from mydb."Cars"
	group by Origin
	order by count(*) desc, Origin
;
quit;
title;
