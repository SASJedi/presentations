/******************************************************************************
 Server-side vs. Client-side Loading
 Step 1 - Viewing caslib contents from Compute Server
******************************************************************************/
/* Compare PROC CONTENTS results  */
title "Contents viewed from the Compute Server";
title2 "SAS libref with the DBMS schema as the data source";
proc contents data=mydb._all_ nods;
run;
title2 "Caslib with the DBMS schema as the data source";
proc contents data=myCASDB._all_ nods;
run;
title;

/******************************************************************************
 Notes for PROC CONTENTS (the view from the Compute Server)
 - PROC CONTENTS for the SAS library lists the names of the MySQL tables in 
   the database schema, treating them as tables.
 - PROC CONTENTS for the caslib indicates no tables are loaded, treating the 
   tables in the database schema as files.
******************************************************************************/

/******************************************************************************
 Step 2 - Viewing caslib contents from CAS
******************************************************************************/
proc casutil;
title "Contents viewed from the Compute Server";
title2 "myCASDB caslib data source files";
   list files incaslib="myCASDB" DATASOURCEOPTIONS=(schema="wwdv4");
quit;
title;

/******************************************************************************
 Notes for PROC CASUTIL (the view from CAS)
  - DBMS tables are listed as files
  - Identifiers (names) are mixed case
  - MySQL identifiers are case sensitive
******************************************************************************/

/******************************************************************************
 Step 3 - Compare client-side vs. server-side load.
******************************************************************************/
/* Client-side load from a Compute Server SAS/ACCESS libref (DB) to caslib in-memory table*/
proc casutil;
   load data=mydb.Mortgages 
        casout="mortgages_client_side" outcaslib="myCASDB" replace;
quit;

/* Server-side load from the caslib myCASDB MySQL data source to in-memory table */
proc casutil;
   load casdata="Mortgages"  incaslib="myCASDB"
         casout="mortgages_server_side" outcaslib="myCASDB" replace;
quit;

/******************************************************************************
 Note that the data loaded faster when loaded server-side (from the 
 caslib data source) instead of client-side (from the SAS/ACCESS libref). 

 Thumb rule: 
 Load CAS tables from the caslib data source (server-side load) when possible.
******************************************************************************
 Step 5 - A little clean up of caslib memory 
******************************************************************************/
proc  datasets library=myCASDB nolist nodetails kill; 
run; quit;
/******************************************************************************
 Notes 
  - No tables are loaded in the caslib
  - As before, DBMS table are listed as "files"
******************************************************************************/
/******************************************************************************
 Step 8 - Apparent implicit passthrough with FedSQL
******************************************************************************/
title "Implicit Passthrough - CAS has no tables loaded";
proc fedsql sessref=conn iptrace _method;
select count(*) 
   from myCASDB."Mortgages"
;
quit;

/******************************************************************************
 Note 
 - This ran pretty fast, but not lightning speed. 
 - IPTRACE messages appear as WARNINGs
 - IPTRACE indicates unable to fully push-down to the database. 
 - _METHOD shows that the table was loaded to CAS, and aggregation accomlished 
   with CAS actions. 
******************************************************************************/

/******************************************************************************
 Step 9 - Explicit passthrough with FedSQL
******************************************************************************/
title2 "Explicit query";
proc FedSQL sessref=conn iptrace;
select * from connection to myCASDB
   (select count(*) from wwdv4.Mortgages);
quit;
title;
/******************************************************************************
 Note Explicit ran 10x faster than the implicit query.
******************************************************************************/
/******************************************************************************
 Step 7 - Attempt implicit passthrough with DATA step
******************************************************************************/
data myCASDB.grade_a
     myCASDB.grade_b 
	 myCASDB.grade_c
	 myCASDB.grade_d 
     /sessref=conn
	 ;
   set myCASDB."Mortgages"n;
   where loangrade in ('A','B','C','D');
   select (LOANGRADE);
      when ('A') output myCASDB.grade_a;
      when ('B') output myCASDB.grade_b;
      when ('C') output myCASDB.grade_c;
      when ('D') output myCASDB.grade_d;
   end;
run;

/******************************************************************************
 Note that the DATA step fails because the desired table is not in CAS memory.  
******************************************************************************/
/******************************************************************************
 Step 10 - Explicit FedSQL pass-through with DS2
******************************************************************************/
proc ds2 sessref=conn;
data myCASDB.grade_a
     myCASDB.grade_b 
	 myCASDB.grade_c
	 myCASDB.grade_d 
     /overwrite=yes;
   method run();
	   set {select * from connection to myCASDB
			(select * from wwdv4.Mortgages where loangrade in ('A','B','C','D'))};
	   select (LOANGRADE);
	      when ('A') output myCASDB.grade_a;
	      when ('B') output myCASDB.grade_b;
	      when ('C') output myCASDB.grade_c;
	      when ('D') output myCASDB.grade_d;
	   end;
   end;
enddata;
run;
quit;

/******************************************************************************
 Step 11 - Loading a CAS table with FedSQL pass-through
******************************************************************************/
proc FedSQL sessref=conn;
drop table myCASDB.Summary force;
create table myCASDB.Summary as
select * from connection to myCASDB
(select LoanGrade
      ,cast(Count(*) as Double) as "Number"
      , sum(Amount) as "Total"
      , avg(amount) as "Avg"
	from wwdv4.Mortgages
	where year(LastPayment)=2022
	group by LoanGrade)
;
quit;
proc casutil;
title "myCASDB caslib tables (MySQL tables loaded in CAS memory)";
   list tables incaslib="myCASDB";
quit;
/******************************************************************************
 Note:
 - Original table is 6.6M rows, would take ~2 minutes to load to CAS
 - I only need the summary to work with in CAS 
 - With pass-through, summarized data loaded to a CAS table in a few seconds
******************************************************************************/
/* Working with CAS tables using Compute Server processes */
ods pdf file="&path/results/myreport.pdf" startpage=no;
title "Mortgage Totals by Loan Type";
proc sgplot data=myCASDB.Summary;
	vbar LoanGrade/response=Total;
	keylegend / location=inside position=topright;
run;
proc sql;
select 	 LoanGrade
		,Number format=comma12.
		,Avg format=dollar12.2
		,Total format=dollar20.2
	from myCASDB.Summary
	order by LoanGrade
;
quit;
ods pdf close;
title;

/******************************************************************************
 Step 12 - Saving a CAS table as a database table (write permission required)
******************************************************************************/
proc casutil;
	save casdata="Summary" incaslib="myCASDB"
		 casout="MortgageSummary" outcaslib="myCASDB";
title2 "myCASDB caslib data source files";
	list files incaslib="myCASDB" DATASOURCEOPTIONS=(schema="wwdv4");
run;


