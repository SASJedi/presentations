/* A quick introduction to explicit pass-through - PROC SQL */
title "PROC SQL - Explicit Pass-through Results";
title2 "Select * from Cars";
proc sql;
	connect using mydb;
	select * from connection to mydb 
		(select * from wwdv4.Cars limit 5);
title2 "MySQL JSON_ARRAY function";
	select * from connection to mydb 
		(select convert(JSON_ARRAY(Make, Model, Type, MSRP, MPG_Highway ), CHAR(100)) 
			as "JSON [Make, Model, Type, MSRP, MPG]"
			from wwdv4.Cars limit 5);
	disconnect from mydb;
quit;

/* PROC FedSQL explicit pass-through. Use libref, no connect and disconnect statement  */
title "PROC FedSQL - Explicit Pass-through Results";
title2 "Select * from Cars";
proc fedsql;
	select * from connection to mydb 
		(select * from wwdv4.Cars limit 5);
title2 "MySQL JSON_ARRAY function";
	select * from connection to mydb 
		(select convert(JSON_ARRAY(Make, Model, Type, MSRP, MPG_Highway ), CHAR(100)) 
			as "JSON [Make, Model, Type, MSRP, MPG]"
			from wwdv4.Cars limit 5);
quit;

