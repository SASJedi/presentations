/******************************************************************************
 Eliminating Cross-Library Operations
******************************************************************************/
/* Step 1 - The cross-library join  */
libname xl xlsx "&path/data/marketing.xlsx";
options sastrace=',,,d' sastraceloc=saslog nostsuffix;

proc SQL;
create table cross_library as
select o.Customer_ID
      ,o.Customer_Name
      ,count(*) as Orders
      ,sum(total_sale) as Total_Spent
   from mydb.Orders o
      inner join
        xl.top100 t
      on o.Customer_ID=t.Customer_ID
   group by  o.Customer_ID
            ,o.Customer_Name
   order by o.Customer_ID
;
quit;

libname xl clear;
options sastrace=off;
/******************************************************************************
 Note: This cross-library join took about several seconds to complete.  
******************************************************************************/

/******************************************************************************
 Step 2 - Eliminating the Cross-Library join
      2.a: Load the Excel table to temporary table space in the database.
Note: Many databases allow temporary tables. Examples include DB2, Hadoop, 
	  MS SQL Server, MySQL, Oracle, PostgreSQL, SAP HANA, SingleStore, 
	  Snowflake, and Teradata
******************************************************************************/
/* Access temporary table space in the database */
libname dbTemp mysql server="server.demo.sas.com" port=3306 
			database=wwdv4 connection=global dbcommit=0 dbmstemp=yes
			user="&userID" password="&password";

libname xl xlsx "/home/student/Courses/etdp/data/marketing.xlsx";

/* Just in case the table already exists :-) */
proc FedSQL;
   drop table dbTemp.top100 force;
quit;

proc append base=dbTemp.top100(BL_DEFAULT_DIR="&path/data" bulkload=yes)
            data=xl.top100;
run;

libname xl clear;

/******************************************************************************
 Note: The table upload took less than one second.
******************************************************************************/

/******************************************************************************
 Step 2.b: Now the join can happen in the database.
******************************************************************************/
options sastrace=',,,d' sastraceloc=saslog nostsuffix;
title "Inner Join - Temp table";
proc SQL;
create table database_join as
select o.Customer_ID
      ,o.Customer_Name
      ,count(*) as Orders
      ,sum(total_sale) as Total_Spent
   from myDB.Orders o
      inner join
        dbTemp.top100 t
      on o.Customer_ID=t.Customer_ID
   group by  o.Customer_ID
            ,o.Customer_Name
   order by o.Customer_ID
;
quit;
title ;
options sastrace=off;
/******************************************************************************
 Note: This entire process ran in about half the time required for the 
	   cross-library join.
******************************************************************************/