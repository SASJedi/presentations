data mysas.Customers;
  infile datalines dsd truncover;
  input Customer_ID:5. Type_ID:4. Name:$50. Address:$50. City:$50. State:$2. Postal_Code:$10. 
		Country:$3. Gender:$1. Customer_Age:32. Birthday:YYMMDD10. 
		First_Purchase:YYMMDD10. Last_Purchase:YYMMDD10.;
  format CUSTOMER_ID Z5. TYPE_ID Z4. BIRTHDAY YYMMDD10. FIRST_PURCHASE YYMMDD10. LAST_PURCHASE YYMMDD10.;
  label CUSTOMER_ID="CUSTOMER ID" TYPE_ID="CUSTOMER TYPE";
