/* Set up */
%let PATH=/home/student/win_share/wwdv4;
%let userID=student;
%let password=Metadata0;

libname dba mysql server="server.demo.sas.com" port=3306 database=sys
			user="&userID" password="&password";

proc sql;
   connect using dba;
   execute (DROP database if exists wwdv4 ) by dba;
   execute (create database wwdv4) by dba;
   disconnect from dba;
quit;
libname dba;

%include "&path/libnames-mysql.sas";
proc datasets library=mydb kill nolist nodetails;
run; quit;

/* Make Data */
/* Make SAS Data */
%include"&path/data/makeCustomersHead.sas";
%include"&path/data/makeCustomersData.sas";
%include"&path/data/makeMortgagesHead.sas";
%include"&path/data/makeMortgagesData.sas";
%include"&path/data/makeOrdersHead.sas";
%include"&path/data/makeOrdersData.sas";

/* Make DBMS Data */
proc sql;
connect using mydb;

execute(drop TABLE IF EXISTS Cars) by mydb;
execute(
CREATE TABLE Cars
  (
   Make varchar(13),
   Model varchar(40),
   Type varchar(8),
   Origin char(6),
   DriveTrain char(5),
   MSRP DOUBLE,
   Invoice DOUBLE,
   EngineSize DOUBLE,
   Cylinders INT,
   Horsepower INT,
   MPG_City DOUBLE,
   MPG_Highway DOUBLE,
   Weight INT,
   Wheelbase INT,
   Length INT
  )
)by mydb;

execute(drop TABLE IF EXISTS Customers) by mydb;
execute (
CREATE TABLE Customers
	(
    Customer_ID Bigint,
    Type_ID Int,
    Name Varchar(50),
    Address Varchar(55),
    City Varchar(50) ,
    State Char(2),
    Postal_Code Varchar(10) ,
    Country Char(3),
    Gender Char(1),
    Customer_Age Int,
    Birthday Date,
    First_Purchase Date,
    Last_Purchase Date
	)
)by mydb;

execute(drop TABLE IF EXISTS Mortgages) by mydb;
execute(
CREATE TABLE Mortgages
  (
   ID varchar(25),
   AccNumber varchar(30),
   SalaryGroup varchar(20),
   Age INT,
   Salary BIGINT,
   EmpLength INT,
   Category varchar(15),
   Amount double,
   InterestRate double,
   LoanLength INT,
   LoanGrade char(1),
   LoanStatus varchar(20),
   Cancelled INT,
   CancelledReason varchar(50),
   Promotion INT,
   LastPayment DATE ,
   Updated DATE 
  )
) by mydb;

execute (drop table if exists Orders) by mydb;
execute (
CREATE TABLE Orders (
     Order_ID			BIGINT
	,Product_ID			BIGINT
	,Customer_ID		BIGINT
	,Employee_ID		BIGINT
	,Order_Date			DATE
	,Delivery_Date		DATE
	,Order_Type			INT
	,Quantity			INT
	,Total_Sale			DOUBLE
	,Discount			DOUBLE
	,Unit_Price			DOUBLE
	,Retail_Price		DOUBLE
	,Product_Line		VARCHAR(20)
	,Product_Catagory	VARCHAR(25)
	,Product_Group		VARCHAR(25)
	,Product_Name		VARCHAR(45)
	,Supplier_Country	VARCHAR(2)
	,Supplier_Name		VARCHAR(30)
	,Supplier_ID		BIGINT
	,Customer_Type_ID	INT
	,Customer_Name		VARCHAR(40)
	,Customer_Address	VARCHAR(45)
	,City_Name			VARCHAR(30)
	,Customer_State		VARCHAR(2)
	,Postal_Code		VARCHAR(10)
	,Country			VARCHAR(2)
	,Gender				VARCHAR(1)
	,Customer_Age		INT
	,Birth_Date			DATE
	,First_Purchase_Date DATE
	,Last_Purchase_Date	DATE
)
) by mydb;

disconnect from mydb;
quit;

proc append base=mydb.Cars
		    data=sashelp.Cars force;
run;

proc append base=mydb.Customers
		    data=mysas.Customers force;
run;

proc append base=mydb.Mortgages(BULKLOAD=YES)  
		    data=mysas.Mortgages force;
run;
proc append base=mydb.Orders
		    data=mysas.Orders force;
run;

proc casutil ;
	load casdata="Customers" incaslib="myCASDB" casout="Customers" outcaslib="myCAS" replace;
	save casdata="Customers" incaslib="myCAS" casout="customers.sashdat" outcaslib="myCAS" replace;
	load casdata="Mortgages" incaslib="myCASDB" casout="Mortgages" outcaslib="myCAS" replace;
	save casdata="Mortgages" incaslib="myCAS" casout="mortgages.sashdat" outcaslib="myCAS" replace;
	load casdata="Orders" incaslib="myCASDB" casout="Orders" outcaslib="myCAS" replace;
	save casdata="Orders" incaslib="myCAS" casout="orders.sashdat" outcaslib="myCAS" replace;
quit;

/* Clean Up */
libname myDB clear;
libname mySAS clear;
cas conn terminate;
