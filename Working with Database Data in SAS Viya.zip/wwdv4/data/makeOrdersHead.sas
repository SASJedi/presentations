data mySAS.Orders;
  infile datalines dsd truncover;
  input Order_ID:13. Product_ID:13. Customer_ID:13. Employee_ID:13. Order_Date:DATE9. Delivery_Date:DATE9. 
		Order_Type:32. Quantity:32. Total_Sale:COMMA8.2 Discount:PERCENT6.2 Unit_Price:32. Retail_Price:32. 
		Product_Line:$80. Product_Category:$100. Product_Group:$100. Product_Name:$180. 
		Supplier_Country:$8. Supplier_Name:$120. Supplier_ID:32. 
		Customer_Type_ID:32. Customer_Name:$40. Customer_Address:$45. City_Name:$30. Customer_State:$2. 
		Postal_Code:$10. Country:$2. Gender:$1. Customer_Age:32. Birth_Date:MMDDYY10. 
		First_Purchase_Date:MMDDYY10. Last_Purchase_Date:MMDDYY10.;
  format Order_ID Z13. Product_ID Z13. Customer_ID Z13. Employee_ID Z13. Order_Date YYMMDD10. Delivery_Date YYMMDD10. Total_Sale COMMA8.2 Discount PERCENT6.2 Birth_Date YYMMDD10. First_Purchase_Date YYMMDD10. Last_Purchase_Date MMDDYY10.;
