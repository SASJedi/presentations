/* Set up */
%let PATH=/home/student/win_share/wwdv4;
%let userID=student;
%let password=Metadata0;
libname dba postgres server="server.demo.sas.com" port=30432 database=postgres 
   		user="&userID" password="&password" ;

proc sql;
	connect using dba; 
	execute(drop database if exists "WWDV4") by dba;
	execute(create database "WWDV4") by dba;
	disconnect from dba;
quit;

libname dba clear;
%include "&path/libnames.sas";

/* Make SAS Data */
%include"&path/data/makeCustomersHead.sas";
%include"&path/data/makeCustomersData.sas";
%include"&path/data/makeMortgagesHead.sas";
%include"&path/data/makeMortgagesData.sas";
%include"&path/data/makeOrdersHead.sas";
%include"&path/data/makeOrdersData.sas";

/* Make DBMS Data */
proc sql;
connect using mydb;

execute(drop TABLE IF EXISTS public.Customers) by mydb;
execute (
CREATE TABLE Customers
	(
    Customer_ID Bigint,
    Customer_Type_ID Integer,
    Customer_Name Varchar(50),
    Customer_Address Varchar(55),
    City_Name Varchar(50) ,
    Customer_State Char(2),
    Postal_Code Varchar(10) ,
    Country Char(3),
    Gender Char(1),
    Customer_Age Integer,
    Birth_Date Date,
    First_Purchase_Date Date,
    Last_Purchase_Date Date
	)
)by mydb;


execute(drop TABLE IF EXISTS public.Mortgages) by mydb;
execute(
CREATE TABLE public.Mortgages
  (
   ID varchar(25),
   ACCNUMBER varchar(30),
   SALARYGROUP char(20),
   AGE INT,
   SALARY BIGINT,
   EMPLENGTH INT,
   CATEGORY varchar(15),
   AMOUNT double precision,
   INTERESTRATE double precision,
   LOANLENGTH INT,
   LOANGRADE char(1),
   LOANSTATUS char(20),
   CANCELLED INTEGER,
   CANCELLEDREASON varchar(50),
   PROMOTION INTEGER,
   LastPayment DATE ,
   Updated DATE 
  )
) by mydb;

execute(drop TABLE IF EXISTS public.cars) by mydb;
execute(
CREATE TABLE public.cars
  (
   Make varchar(13),
   Model varchar(40),
   Type varchar(8),
   Origin char(6),
   DriveTrain char(5),
   MSRP double precision,
   Invoice double precision,
   EngineSize double precision,
   Cylinders integer,
   Horsepower integer,
   MPG_City double precision,
   MPG_Highway double precision,
   Weight integer,
   Wheelbase integer,
   Length integer
  )
)by mydb;

disconnect from mydb;
insert into mydb.cars
	select * from sashelp.cars;
insert into mydb.customers
	select * from mysas.customers;
insert into mydb.mortgages
	select * from mysas.mortgages;
quit;

proc casutil ;
	load casdata="customers" incaslib="myCASDB" casout="customers" outcaslib="myCAS" replace;
	save casdata="customers" incaslib="myCAS" casout="customers.sashdat" outcaslib="myCAS" replace;
	load casdata="mortgages" incaslib="myCASDB" casout="mortgages" outcaslib="myCAS" replace;
	save casdata="mortgages" incaslib="myCAS" casout="mortgages.sashdat" outcaslib="myCAS" replace;
	load casdata="orders" incaslib="myCASDB" casout="orders" outcaslib="myCAS" replace;
	save casdata="orders" incaslib="myCAS" casout="orders.sashdat" outcaslib="myCAS" replace;
quit;

/* Clean Up */
libname myDB clear;
libname myDBTemp clear;
libname mySAS clear;
cas conn terminate;
