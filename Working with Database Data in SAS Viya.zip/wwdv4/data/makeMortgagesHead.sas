data mysas.Mortgages;
  infile datalines dsd truncover;
  input ID:$25. AccNumber:$30. SalaryGroup:$20. Age:32. Salary:32. EmpLength:32. 
		Category:$15. Amount:32. InterestRate:32. LoanLength:32. LoanGrade:$1. LoanStatus:$20. 
		Cancelled:32. CancelledReason:$50. Promotion:32. LastPayment:YYMMDD10. Updated:YYMMDD10.;
  format LastPayment YYMMDD10. Updated YYMMDD10.;
