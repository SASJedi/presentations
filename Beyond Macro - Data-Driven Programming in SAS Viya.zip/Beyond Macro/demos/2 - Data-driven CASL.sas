/******************************************************************************
 Data-driven CASL
******************************************************************************/
/******************************************************************************
 Section 1.a: Load all files from a caslib's data source using SAS Macro
******************************************************************************/
/* To start, make sure all CAS tables are unloaded */
proc datasets library=casuser kill nolist nodetails;
run; quit;

/* Traditional macro techniques */
/* Open macro definition loadfiles.sas and review, then run this section */

%include "&path/macros/loadfiles.sas" /source2;

options mprint;
%loadFiles(casuser,&path/data)

title "Tables in CASUSER";
proc casutil;
	list tables incaslib="casuser";
run; quit;


/******************************************************************************
 Section 1.b: Load all files from a caslib's data source using CASL & CAS actions
******************************************************************************/
/* Clear the decks for the next section */
proc datasets library=casuser kill nolist nodetails;
run; quit;
/* Show that CASUSER has no tables loaded in the Libraries pane */
proc cas;
	title "Files available to be loaded in CASUSER";
	table.fileInfo/caslib="casuser";
	title;
run; quit;

/* CASL result tables and a DO OVER loop */
proc cas;
thisCaslib="casuser";
/* List files in the caslib, result in a dictionary */
table.fileInfo result=rFileInfo/caslib=thisCaslib;

/* Extract table of filenames (named FileInfo) from the result dictionary */
files=rFileInfo.FileInfo;

/* Loop over dictionary, load the files as CAS tables */
do key,value over files;
	print "Loading " value.name " to CASUSER";
	table.loadTable/
		caslib=thisCaslib
		path=value.name
      casout={name=scan(value.name,1,'.'),caslib=thisCaslib,replace=TRUE}
	;
end;
title "Tables loaded in CASUSER";
table.tableInfo/
	caslib=thisCaslib;
title;
run;
/******************************************************************************
 Section 2.a: Print a few rows of every table in a CASLIB using SAS Macro
******************************************************************************/
%macro listCASTables(CASlibref);
proc sql noprint;
select distinct strip(memname)
	into :table1- 
    from dictionary.tables
	where libname="%qupcase(%superq(CASlibref))"
;
quit;

proc cas;
/* Generate a table.fetch call for 5 rows of each table */
%do I=1 %to &SQLObs;
table.fetch/ 
	table={caslib="%superq(CASlibref)", name="&&table&i"}
	,to=5
	,index=FALSE
;
%end;
run; quit;
%mend;

/*Call the macro for the CASUSER libref */
%listCASTables(casuser);

/********************************************************************************
 Section 2.b: Print a few rows of every table in a CASLIB using CASL & CAS actions
********************************************************************************/
/* CASL - no macro required */
proc cas;
table.tableInfo result=resultDictionary/
	caslib="casuser";

/* Iterate over the result table without first extracting it from the result dictionary */
do thisTable over getcolumn(resultDictionary.TableInfo, "Name");
	table.fetch/ 
		table={caslib="casuser", name=thisTable}
		,to=5
		,index=FALSE
;
end;
run; quit;
title;
/* Can I make this a function, kind of like the macro definition? */

