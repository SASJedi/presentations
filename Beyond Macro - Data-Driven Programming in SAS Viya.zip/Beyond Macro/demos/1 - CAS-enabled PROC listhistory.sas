%let myMake=Oldsmobile;

/* From a SAS Data Set */
title "PROC PRINT - sashelp.cars";
proc print data=sashelp.cars;
	var Make Model Type Origin MSRP Invoice;
	where make="&myMake";
run;

/****************************************************************************** 
 What if the data was in a database instead of a SAS Data Set?
******************************************************************************/
/* SASTRACE allows us to see what SAS actually "said" (SQL) to the database */
options sastrace=',,,d' sastraceloc=saslog nostsuffix;

/* Using implicit pass-through to PostgreSQL - SAS?ACCESS writes the SQL */
title "PROC PRINT - db.cars";
proc print data=db.cars;
	var Make Model Type Origin MSRP Invoice;
	where make="&myMake";
run;

/* Using explicit pass-through to PostgreSQL - write your own SQL */
title "PROC SQL with Explicit pass-through to PostgreSQL";
proc SQL;
connect using db;
select *
	from connection to db
	(select Make, Model, Type, Origin, MSRP, Invoice
		from CARS
		where make=%tslit(&myMake));
disconnect from db;
quit;
options sastrace=off;

/****************************************************************************** 
 Now, what if the data was in a CAS table instead?
******************************************************************************/
/* From a CAS table */
title "PROC PRINT from CAS";
proc print data=casuser.cars;
	var Make Model Type Origin MSRP Invoice;
	where make="&myMake";
run;
/* See what SAS actually "said" to CAS */
cas casauto listhistory 2;

/* Let's do this explicitly using CASL and CAS Actions */
proc cas;
/* Copy the CAS Action code from the log */
title "PROC CAS - table.fetch CAS action";
table.fetch / 
	table={name='CARS', caslib='casuser', where="(make='Oldsmobile')"
		  ,vars={{name='Make'}
				,{name='Model'}
			    ,{name='Type'}
				,{name='Origin'} 
				,{name='MSRP'}
				,{name='Invoice'}}}
		,from=1
	    ,to=428
		,sasTypes=false
		,index=false
; 
quit;

/* There aren't really 428 rows in the output. Can we be more precise? */
proc cas;
/* Create a CASL variable with the table specs for ease of use */ 
myTable={name='CARS', caslib='casuser', where="(make='Oldsmobile')"
		  ,vars={{name='Make'}
				,{name='Model'}
			    ,{name='Type'}
				,{name='Origin'} 
				,{name='MSRP'}
				,{name='Invoice'}}};

simple.numrows result=count
	/table=myTable;
print count;
print "NOTE: Simple.numrows produced a dictionary named COUNT with one entry named NUMROWS.";
print "The value of count.numrows is " count.numrows;
quit;

proc cas;
title "PROC CAS - table.fetch CAS action with data-driven TO parameter";
/* Create a CASL variable with the table specs for ease of use */ 
myTable={name='CARS', caslib='casuser', where="(make='Oldsmobile')"
		  ,vars={{name='Make'}
				,{name='Model'}
			    ,{name='Type'}
				,{name='Origin'} 
				,{name='MSRP'}
				,{name='Invoice'}}};

simple.numrows result=count/ 
	table=myTable;

table.fetch / 
   table=myTable
         from=1,
		/* Use count.numrows here to insert the correct value */
		 to=count.numrows
		,sasTypes=false
		,index=false
; 
run; quit;
cas casauto listhistory 2;
title;
