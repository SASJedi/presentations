/******************************************************************************
 Data-driven CASL User-defined Functions
******************************************************************************/
/******************************************************************************
 Secton 1: Roll your own CASL function
******************************************************************************/
proc cas;
function printTables(caslib);
	table.tableInfo result=rDict/caslib=caslib;
		do thisTable over getcolumn(rDict.TableInfo, "Name");
			table.fetch/ 
				 table={caslib=caslib, name=thisTable}
				,to=5
				,index=FALSE
			;
		end;
end;

/* Verify that CAS knows about my function */
functionlist printTables;

/* Use my new function to print tables in the SESUG caslib */
printTables("casuser");
run; quit;

/******************************************************************************
 Secton 2: Functions don't persist after the PROC CAS session quits. Use  
 readpath() and execute() to recreate all functions from a single code file.
******************************************************************************/
/* Unload all of the tables in CASUSER */
proc datasets library=casuser kill nolist nodetails;
run; quit;

proc cas;
	/* Read in & execute the User Defined Functions code */
	myUDF = readpath("&path/udf/casl-udf.sas");
	execute(myUDF);
	/* Use the functions as if they were built into CAS */
	loadAllFiles("casuser");
	printTables("casuser");
run;quit;
