/**************************************************************************************************************
*If required macros are not available, submit these steps to get them from Github ;
%if not (%sysfunc(CEXIST(WORK.SASMACR.COMPRESS.MACRO))) %then %do;
	filename macropgm url "https://raw.githubusercontent.com/SASJedi/sas-macros/refs/heads/master/compress.sas";
	%include macropgm /source2;
	filename macropgm clear;
%end;

%if not (%sysfunc(CEXIST(WORK.SASMACR.TRANSLATE.MACRO))) %then %do;
	filename macropgm url "https://raw.githubusercontent.com/SASJedi/sas-macros/refs/heads/master/translate.sas";
	%include macropgm /source2;
	filename macropgm clear;
%end;

%if not (%sysfunc(CEXIST(WORK.SASMACR.WHEREAMI.MACRO))) %then %do;
	filename macropgm url "https://raw.githubusercontent.com/SASJedi/sas-macros/refs/heads/master/whereami.sas";
	%include macropgm /source2;
	filename macropgm clear;
%end;
**************************************************************************************************************/

/******************************************************************************
 Section 1 - Setup: Connect to CAS and load data
******************************************************************************/
%let path=%whereami();

libname casuser cas caslib="casuser";
libname db postgres server="&pgServer" port="&pgPort" database="&pgDBName"
        user="&pgAdminID" password="&pgAdminPW" database="BEYONDMACRO";

/* Save some SASHELP datasets in sashdat format in CASUSER */
proc casutil;
	load data=sashelp.heart casout="heart" outcaslib="casuser" replace;	
	save casdata="heart"  incaslib="casuser" casout="heart.csv" outcaslib="casuser" replace; 
	load data=sashelp.iris casout="iris" outcaslib="casuser" replace;
	save casdata="iris"  incaslib="casuser" casout="iris.xlsx" outcaslib="casuser" replace; 
	load data=sashelp.cars casout="cars" outcaslib="casuser" replace;	
	save casdata="cars"  incaslib="casuser" casout="cars.sashdat" outcaslib="casuser" replace; 
	list files incaslib="casuser";	
	list tables incaslib="casuser";	
run;
quit;
