function printTables(thisCaslib);
	table.tableInfo result=rDict/caslib=thisCaslib;
	do thisTable over getcolumn(rDict.TableInfo, "Name");
		table.fetch/ 
			 table={caslib=thisCaslib, name=thisTable}
			,to=5
			,index=FALSE;
	end;
end;
function loadAllFiles(thisCaslib);
	/* List files in the caslib, result in a dictionary */
	table.fileInfo result=rFileInfo/caslib=thisCaslib;
	
	/* Extract table of filenames (named FileInfo) from the result dictionary */
	files=rFileInfo.FileInfo;
	
	/* Loop over dictionary, load the files as CAS tables */
	do key,value over files;
		print "Loading " value.name " to " thisCaslib;
		table.loadTable/
			caslib=thisCaslib
			path=value.name
	      casout={name=scan(value.name,1,'.'),caslib=thisCaslib,replace=TRUE}
		;
	end;
	table.tableInfo/caslib=thisCaslib;
end;
