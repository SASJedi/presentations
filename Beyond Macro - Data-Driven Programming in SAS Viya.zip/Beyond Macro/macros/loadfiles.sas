%macro loadFiles(caslib, path)/minoperator mindelimiter='|';
  /***************************************************************************
   Created by Mark Jordan - http://go.sas.com/jedi
   Last Modified: 2020-06-03
   This macro program (loadfiles.sas) can be placed in your AUTOCALL path.
 ***************************************************************************/
	%local fileref rc did i n memname didc cmd nummem ext;
	%let ext=CSV|SAS7BDAT|SASHDAT|XLSX;
	%if %superq(caslib) = %then
	%do;
	   %let MsgType=ERROR;
	      %PUT &MsgType:  *&SYSMACRONAME Error *******************************;
	   %put &MsgType: You must specify a directory.;
	   %return;
	%end;
	%if %superq(path) = %then 
	%do;
	   %let MsgType=ERROR;
	      %PUT &MsgType:  *&SYSMACRONAME Error *******************************;
	   %put &MsgType: You must specify the path to the caslib data source.;
	   %return;
	%end;
   %let rc=%sysfunc(filename(fileref,%superq(path)));
   %let did=%sysfunc(dopen(%superq(fileref)));
   %if &did=0 %then 
	%do;
      %put ERROR: Directory %qupcase(%superq(path)) does not exist.;
      %return;
   	%end;

	/* Do the work */
   %let nummem=0;

   %do n=1 %to %sysfunc(dnum(&did));
      %let memname=%qsysfunc(dread(&did,&n));
		%if %qupcase(%qscan(%superq(memname),-1,.)) in %qupcase(%superq(ext)) %then 
		%do;
            %let nummem=%eval(&nummem+1);
            %local mem&nummem;
            %let mem&nummem=%superq(memname);
         %end;
      %end;

   %let didc=%qsysfunc(dclose(%superq(did)));
   %let rc=%qsysfunc(filename(fileref));
   %if &nummem > 0 %then 
	%do;
		proc casutil;
		%do i=1 %to &nummem;
			load casdata="&&mem&i"              incaslib="%superq(caslib)"
				  casout="%qscan(&&mem&i,1,.)" outcaslib="%superq(caslib)" replace;
		%end;
	%end;
	run; quit;
%mend loadfiles;
