/* NOTE: Ensure no CAS connection is established */
proc cas;
session.listSessions;
run; quit;
cas casauto terminate;

/* Step 1 */
%let Test=Created using SAS Macro code.;
%put NOTE: In Base SAS before PROC CAS, &=Test;
proc cas;
	/* Set a macro variable value */
	symput("Test","Created in step 1 using CASL");
	/* Set a CASL variable value */
	Test="My CASL Variable";
	/* Print the macro variable value */
	print (NOTE) 'In PROC CAS, Macro variable Test= ' "&test";
	/* Print the CASL variable value */
	print (NOTE) 'In PROC CAS, CASL variable Test= ' test;
run;quit;

/* After PROC CAS terminates */
%put NOTE: In Base SAS after PROC CAS quits, macro variable &=Test;

/* Step 2 */
/* Macro variables persist for the SAS session,
   CASL variables persist only for the PROC CAS step */
proc cas;
	print (NOTE) 'In PROC CAS, Macro variable Test=' "&test";
	print (NOTE) 'In PROC CAS, CASL variable Test=' test;
run;quit;
%put NOTE: In Base SAS after PROC CAS quits, macro variable &=Test;

/* You can use both macro and CASL variable values in CASL code */
%let Test=CASL testing;
proc cas;
	Test="CASL testing";
	if "&Test"=Test then do;
		print (NOTE) "The macro and CASL variables are the same";
		symput('Test','The CASL test went well.');
	end;
	else do;
		print (NOTE) "The macro and CASL variable values are different:";
		print (NOTE) '   Macro variable Test=' "&test";
		print (NOTE) '    CASL variable Test=' test;
	end;
run;quit;

%put NOTE: In Base SAS after PROC CAS quits, macro variable &=Test;

/**************************************************************************
 Step 1 - CASL normally runs in Compute
**************************************************************************/
/* Connect to CAS */
cas conn;
%let Test=Created with SAS Macro;
%put NOTE: Before PROC CAS, &=Test;
proc cas ;
	session conn;
	/* Set the value of a macro variable named Test */
	symput("Test","Created in CAS");
	/* Set a different value in a CASL variable, also named Test */
	Test="My CASL Variable";
	/* Prove that the macro variable and CASL variable are not the same */
	/* Print the macro variable value */
	print '** In PROC CAS, &Test= ' "&test";
	print '** In PROC CAS, symget("Test")= ' symget("Test");
	/* Print the CASL variable value */
	print '** In PROC CAS, CASL variable Test= ' test;
run;
quit;

/* Note that CASL SYMPUT modified the value of Test in the Global Symbol Table: */
%put NOTE: After PROC CAS, &=Test;

/**************************************************************************
 Step 2 - Force CASL to run in CAS by executing with a CAS action
**************************************************************************/
%let Test=Created with SAS Macro;
%put NOTE: Before PROC CAS, &=Test;
proc cas ;
	session conn;
	source myCASLProgram;
		/* Set the value of a macro variable named Test */
		symput("Test","Created in CAS");
		/* Set a different value in a CASL variable, also named Test */
		Test="My CASL Variable";
		/* Prove that the macro variable and CASL variable are not the same */
		/* Print the macro variable value */
		print '** In PROC CAS, &Test= ' "&test";
		print '** In PROC CAS, symget("Test")= ' symget("Test");
		/* Print the CASL variable value */
		print '** In PROC CAS, CASL variable Test= ' test;
	endsource;
	sccasl.runCasl result=r /
		code=myCASLProgram;
run;
quit;

/* Note that the value of Test in the Global Symbol Table now remains unchanged: */
%put NOTE: After PROC CAS, &=Test;

cas conn terminate;