/******************************************************************************
  CASL Arrays 
******************************************************************************/
proc cas;
   x={10, "Mark", "555-1212"};
   describe x;
   print "Element 2 is " x[2];
   do value over x;
   	count=sum(count,1);
      print "Element " count "is " value;
   end;
run; quit;

/******************************************************************************
  CASL Dictionaries 
******************************************************************************/
proc cas;
   employee={ID=10
   			,Name="Mark"
   			,Title="SAS Jedi"
   			,Phone="555-1212"};
   describe employee;
   print "Phone is " employee.phone;
   do key,value over employee;
      print key "=" value;
   end;
run; quit;

/******************************************************************************
  CASL Result Tables
******************************************************************************/
/* Result table returned by a CAS action */
proc cas;
   simple.crossTab result=actionResult / 
   	table={name="rand_retaildemo", caslib="samples"},
   			 row="State" col="Brand_Name";
   describe actionResult;
/* Note the actioResult is a dictionary with one key named Crosstab 
   of a type Table. Let's extract the table as myTable      */ 
   myTable=actionResult.CrossTab;
   describe myTable;
/* myTable is just a table named Crosstab with 4 columns */ 
/* Let's add compute Total column to myTable */ 
   myTable=myTable.compute({"total", "Total"}, col1 + col2 + col3);
   describe myTable;
   print myTable.where(Total>50000);
/* I'd like the result table saved as a SAS dataset */
   saveresult myTable dataout=work.RetailSummary; 
run;quit;

title "work.RetailSummary - Sales by State";
proc sql;
	select * from RetailSummary;
quit;
title;

proc cas;
   simple.crossTab result=actionResult / 
   	table={name="rand_retaildemo", caslib="samples"},
   			 row="State" col="Brand_Name";
   myTable=actionResult.CrossTab.where(State like 'A%');
   myArray=myTable[,1];
   myDict=myTable[1];
   print(note) "myArray=" myArray;
   do value over myArray;
   	print(Note) " - Array element value is: " value ;
   end;
	print;
	print;
   print(note) "myDict=" myDict;
   do key,value over myDict;
   	print(Note) " - " Key " value is: " value ;
   end;
   print(note) "myTable **** ";
   do row over myTable;
   	print(Note) " - Row value is: " row ;
	   do key,value over row;
	   	print(Note) " - " Key " value is: " value ;
	   end;
   end;
run; quit;

/* User-defined result table */
proc cas;
   employees= newtable("Employee Information"
   						,{"ID",     "Name",    "Title",  "Phone"}
   						,{"integer", "string", "string", "string"});
   describe employees;
   addrow(employees,{10,"Mark","SAS Jedi","555-1111"});
   addrow(employees,{20,"Peter","CASL Guru","555-2222"});
   describe employees;
   print employees;
   saveresult employees dataout=work.Employees; 
run;quit;

title "Saved result table";
proc sql number;
	select * from Employees;
quit;

