/* CASL composite variable types */
cas conn;
proc cas;
/* A CASL ARRAY is an ordered list of values. Values are accessed by position in the array. */
	myArray={1,2,"Czar","Djbouti"};
	print "***************************************************************";
	print "CASL Array";
	describe myArray;
    print "Array element 3 is " myArray[3]; 
	x=0;
	do I over myArray;
		x=x+1;
		print "myArray element " x "= " I;
	end;
	print "***************************************************************";

/* A CASL DICTIONARY is an unordered list of key-valuepairs. Values are accessed by key */
	myDictionary={A="Aisle", B="Bdellium", C="Czar", D="Djbouti"};
	print "***************************************************************";
	print "CASL Dictionary";
	describe myDictionary;
	print "D=" myDictionary.d ", C=" myDictionary.c", B=" myDictionary.B ", A=" myDictionary.A ;
	print "***************************************************************";
quit;

/* ADD code that shows dictionary in a CAS action - and then use a dictionary. */

proc cas;
/* A CASL RESULT TABLE can be thought of as an array of dictionaries */ 
	/* add rows to the table */
	myTable = newtable("People list", {"ID", "NAME", "AGE"}, {"integer", "string", "double"});
	/* add rows to the table */
    addrow(myTable, {1,"Able","45"});
    addrow(myTable, {2,"Baker","50"});
    addrow(myTable, {3,"Charlie","55"});
	print "***************************************************************";
	print "CASL Result Table";
	describe myTable;
	/* Print the third row using ARRAY notation. Note the result is a DICTIONARY */
	print myTable[3];
	/* Print the third row name using dictionary notation */
	print "myTable[3].Name=" myTable[3].Name;
	/* Print the second column, all rows. Note that the result is an ARRAY*/
	print myTable[,2];
	/* Print a column by name, all rows. Note that the result is the same as above.*/
	print getcolumn(myTable, "Name");
	print "***************************************************************";
	/* If you print more than one row, the report goes to the Results tab instead of the log */
	/* Print the first through second rows using ARRAY notation. Note the result is a table */
	print myTable[1:2];
	print myTable;
run;quit;

/* CASL result tables are easily saved as SAS data sets for further processing in Base SAS */
proc cas;
	table.tableInfo result=gcpiTables/
		caslib="GPCI"
	;
	saveresult gcpiTables.TableInfo dataout=work.gpciTables; 
run; quit;
cas conn terminate;
proc print data=work.gpciTables; 
run;
