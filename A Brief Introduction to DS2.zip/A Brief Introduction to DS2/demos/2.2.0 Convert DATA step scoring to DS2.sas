proc dstods2 in="&path/demos/2.1 DATA step scoring.sas"
			out="2.2.1x DS2 data program scoring.sas"
			outdir="&path/demos/";
run;
