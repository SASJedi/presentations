/* View the documentation we added to the package */
proc ds2;
data _null_;
	dcl package sasdata.scoring_package sp();
	method init();
		sp.contents();
		sp.score();
	end;
enddata;
run;
quit;

/* Use the package to score the data */
proc ds2;
	data Scored_pkg/overwrite=yes;
		dcl package sasdata.scoring_package sp();
		DCL double scorevar;
		method run();
			set sasdata.Campaign;
			ScoreVar=sp.Score(im_demmedhomevalue, im_giftavgcard36, im_giftcnt36
			, im_gifttimefirst, im_gifttimelast, statuscat96nk, m_giftavgcard36);
		end;
		enddata;
	run;
quit;