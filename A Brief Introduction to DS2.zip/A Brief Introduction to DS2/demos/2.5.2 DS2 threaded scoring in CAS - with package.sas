/* Copy the package into CAS */
proc casutil;
	load data=sasdata.scoring_package 
	     outcaslib="casuser" casout="scoring_package" replace;
quit;

proc ds2 sessref=casauto;
thread casuser.scorecode/overwrite=yes;
	dcl package casuser.scoring_package sp();
	DCL double scorevar _count;
	drop _:;
	retain FLAG_;
		method run();
			set casuser.CAMPAIGN;
			ScoreVar=sp.Score(im_demmedhomevalue,im_giftavgcard36,im_giftcnt36
            ,im_gifttimefirst,im_gifttimelast,statuscat96nk,m_giftavgcard36);
			_count+1;
		end;
        method term();
             put 'Thread ' _threadid_ 'processed ' _count 'rows.';
        end;
	endthread;
	run;
quit;

proc ds2 sessref=casauto;
	data casuser.scored_ds2_cas / overwrite=yes;
		dcl thread casuser.SCORECODE t;
		method run();
			set from t;
		end;
	enddata;
	run;
quit;