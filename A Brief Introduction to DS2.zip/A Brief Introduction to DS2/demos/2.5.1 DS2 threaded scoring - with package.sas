/* Use the package in a thread */
proc ds2;
	thread sasdata.scorecode/overwrite=yes;
		dcl package SASDATA.scoring_package sp();
		DCL double scorevar _count;
		drop _:;
		retain FLAG_;
		method run();
			set SASDATA.CAMPAIGN;
			ScoreVar=sp.Score(im_demmedhomevalue, im_giftavgcard36, im_giftcnt36
			, im_gifttimefirst, im_gifttimelast, statuscat96nk, m_giftavgcard36);
			_count+1;
		end;
		method term();
			put 'Thread ' _threadid_ 'processed ' _count 'rows.';
		end;
	endthread;
run;
quit;

/* Score using threads */
proc ds2;
	data sasdata.scored_ds2_threads / overwrite=yes;
		dcl thread SASDATA.SCORECODE t;
		method run();
			set from t
			threads=&SYSNCPU;
		end;
	enddata;
run;
quit;