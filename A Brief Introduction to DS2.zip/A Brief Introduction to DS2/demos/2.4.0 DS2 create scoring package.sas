/**********************************************************
 Create the scoring package for the threading demo 
**********************************************************/
proc ds2;
package sasdata.scoring_package/overwrite=yes;
   method contents();
      put ;
      put 'This package contains the following methods:';
      put ' - contents';
      put ' - score';
      put ;
   end;
   method score();
      /*Score method self-documentation*/
      put ;
      put 'The SCORE method scores a campaign data set.';
      put ;
      put ' Syntax: Score(input1, input2, input3, input4, input5, input6, input7)';
      put '         Returns final score as DOUBLE.';
      put ;
      put '    For sasdata.Campaign:';
      put '         Input1 is im_demmedhomevalue';
      put '         Input2 is im_giftavgcard36';
      put '         Input3 is im_giftcnt36';
      put '         Input4 is im_gifttimefirst';
      put '         Input5 is im_gifttimelast';
      put '         Input6 is statuscat96nk';
      put '         Input7 is m_giftavgcard36';
      put ;
      put '   Example:';
      put '   ScoreVar=Score(im_demmedhomevalue,im_giftavgcard36,im_giftcnt36';
      put '      ,im_gifttimefirst,im_gifttimelast,statuscat96nk,m_giftavgcard36);';
      put ;
   end;
   method Score(double input1, double input2, double input3, double input4
              , double input5, double input6, double input7) returns double;
     /*ScoreVar is the target variable*/
      dcl char(12) I_TARGET_B  _ST12;
      dcl double 
          Scorevar p_target_b0 u_target_b _TEMP _P1 _P0 _IY _MAXP _LP0 _LP1 
          _DM_FIND _LMR_BAD _ST5 _2_5 _2_4 _2_3 _2_2 _2_1 _2_0 _6_1 _6_0;
      dcl int i;
      _LMR_BAD = 0.0;
      if MISSING(input1) then
         do;
            _LMR_BAD = 1.0;
            goto DefaultExit;
         end;
      if MISSING(input2) then
         do;
            _LMR_BAD = 1.0;
            goto DefaultExit;
         end;
      if MISSING(input3) then
         do;
            _LMR_BAD = 1.0;
            goto DefaultExit;
         end;
      if MISSING(input4) then
         do;
            _LMR_BAD = 1.0;
            goto DefaultExit;
         end;
      if MISSING(input5) then
         do;
            _LMR_BAD = 1.0;
            goto DefaultExit;
         end;
      _2_0 = 0.0;
      _2_1 = 0.0;
      _2_2 = 0.0;
      _2_3 = 0.0;
      _2_4 = 0.0;
      _2_5 = 0.0;
      do i= 1 to 2000;
           _LP1=SQRT(i/(i+1)+ (i**2/(i+1))**2);  
      end;
      _ST5 = LEFT(TRIM(put(input6, $5.)));
      _DM_FIND = 0.0;
      if _ST5 <= 'F' then
         do;
            if _ST5 <= 'E' then
               do;
                  if _ST5 = 'A' then
                     do;
                        _2_0 = 1.0;
                        _DM_FIND = 1.0;
                     end;
                  else
                     do;
                        if _ST5 = 'E' then
                           do;
                              _2_1 = 1.0;
                              _DM_FIND = 1.0;
                           end;
                     end;
               end;
            else
               do;
                  if _ST5 = 'F' then
                     do;
                        _2_2 = 1.0;
                        _DM_FIND = 1.0;
                     end;
               end;
         end;
      else
         do;
            if _ST5 <= 'N' then
               do;
                  if _ST5 = 'L' then
                     do;
                        _2_3 = 1.0;
                        _DM_FIND = 1.0;
                     end;
                  else
                     do;
                        if _ST5 = 'N' then
                           do;
                              _2_4 = 1.0;
                              _DM_FIND = 1.0;
                           end;
                     end;
               end;
            else
               do;
                  if _ST5 = 'S' then
                     do;
                        _2_5 = 1.0;
                        _DM_FIND = 1.0;
                     end;
               end;
         end;
      if ^_DM_FIND then
         do;
            _2_0 = .;
            _2_1 = .;
            _2_2 = .;
            _2_3 = .;
            _2_4 = .;
            _2_5 = .;
            _LMR_BAD = 1.0;
            goto DefaultExit;
         end;
      _6_0 = 0.0;
      _6_1 = 0.0;
      _ST12 = LEFT(TRIM(put(input7, BEST12.)));
      if _ST12 = '0' then
         do;
            _6_0 = 1.0;
         end;
      else if _ST12 = '1' then
         do;
            _6_1 = 1.0;
         end;
      else
         do;
            _6_0 = .;
            _6_1 = .;
            _LMR_BAD = 1.0;
            goto DefaultExit;
         end;
      _LP0 = 0.0;
      _LP0 = _LP0 + (1.4083626419216E-6) * input1;
      _LP0 = _LP0 + (-0.01129757026733) * input2;
      _LP0 = _LP0 + (0.07014728733418) * input3;
      _LP0 = _LP0 + (0.00325352658053) * input4;
      _LP0 = _LP0 + (-0.03942784854233) * input5;
      _TEMP = 1.0;
      _LP0 = _LP0 + (0.28218821521876) * _TEMP * _6_0;
      _LP0 = _LP0 + (0.0) * _TEMP * _6_1;
      _TEMP = 1.0;
      _LP0 = _LP0 + (-0.04430991827625) * _TEMP * _2_0;
      _LP0 = _LP0 + (0.33212057095241) * _TEMP * _2_1;
      _LP0 = _LP0 + (-0.15280893542678) * _TEMP * _2_2;
      _LP0 = _LP0 + (-0.02184926539233) * _TEMP * _2_3;
      _LP0 = _LP0 + (0.08403485184956) * _TEMP * _2_4;
      _LP0 = _LP0 + (0.0) * _TEMP * _2_5;
      _TEMP = 0.0513406495515 + _LP0;
      if (_TEMP < 0.0) then
         do;
            _TEMP = EXP(_TEMP);
            _P0 = _TEMP / (1.0 + _TEMP);
         end;
      else _P0 = 1.0 / (1.0 + EXP(-_TEMP));
      _P1 = 1.0 - _P0;
      ScoreVar = _P0;
      _MAXP = _P0;
      _IY = 1.0;
      P_TARGET_B0 = _P1;
      if (_P1 > _MAXP + 1E-8) then
         do;
            _MAXP = _P1;
            _IY = 2.0;
         end;
      select (_IY);
         when (1.0)
            do;
               I_TARGET_B = '1';
               U_TARGET_B = 1.0;
            end;
         when (2.0)
            do;
               I_TARGET_B = '0';
               U_TARGET_B = 0.0;
            end;
         otherwise
            do;
               I_TARGET_B = '';
               U_TARGET_B = .;
            end;
      end;
      DefaultExit:
      if _LMR_BAD = 1.0 then
         do;
            I_TARGET_B = '';
            U_TARGET_B = .;
            ScoreVar = .;
            P_TARGET_B0 = .;
         end;
      return Scorevar;
      ;
   end;
endpackage;
run;
quit;


