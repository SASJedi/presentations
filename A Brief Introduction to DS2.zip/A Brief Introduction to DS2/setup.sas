/**********************************************************
 NOTE:
 To be able to run all of the code in this package, you will
 need access to a database instance from your SAS Session.
 Change the LIBNAME DBInfo statement to ppit to your 
 database and provide appropriate credentials.
**********************************************************/

/* database not requierd - uses CAS */
/**********************************************************
libname db postgres server="&pgServer" port="&pgPort" database="&pgDBName"
        user="student" password="Metadata0";
**********************************************************/


/**********************************************************
 Locate path to current program
**********************************************************/
%if not (%sysmacexist(compress)) %then %do;
	filename code url "https://raw.githubusercontent.com/SASJedi/sas-macros/refs/heads/master/compress.sas";
	%include code/source2;
	filename code clear;
%end;
%if not (%sysmacexist(translate)) %then %do;
	filename code url "https://raw.githubusercontent.com/SASJedi/sas-macros/refs/heads/master/translate.sas";
	%include code/source2;
	filename code clear;
%end;
%if not (%sysmacexist(whereami)) %then %do;
	filename code url "https://raw.githubusercontent.com/SASJedi/sas-macros/refs/heads/master/whereami.sas";
	%include code/source2;
	filename code clear;
%end;

%let path=%whereami();

/* Copy the campaign.sashdat file to casuser, if necessary */
filename dest "~/casuser/campaign.sashdat" RECFM=N;
%let rc=%sysfunc(fexist(dest));
%put &=rc;
%if &rc=0 %then %do;
	filename src "&path/data/casdata (transfer to casuser)/campaign.sashdat" recfm=n;
	%let rc=%sysfunc(fcopy(src,dest));
    %let msg=%qsysfunc(sysmsg());
	%put &=rc &=msg;;
	filename src clear;
	%put NOTE: campaign.sashdat copied to casuser;
%end;
filename dest clear;
%SYMDEL RC MSG;

**********************************************************
 System Setup
**********************************************************/
options sastrace=',,,d' sastraceloc=saslog nostsuffix;
cas mySession ;
libname sasdata "&path/data";
libname mycas cas caslib=casuser;

proc casutil;
	load casdata="campaign.sashdat" incaslib="casuser"
	casout="campaign" outcaslib="casuser";
run; quit;

data _null_;
	if not exist('SASDATA.CAMPAIGN') then do;
		cmd=cats('%include "',"&path",'/data/cre8data.sas";');
		rc=dosubl(cmd);
	end;
run;

