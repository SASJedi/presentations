%include "&path/data/banks.sas";
%include "&path/data/campaign.sas";
%include "&path/data/employees.sas";
%include "&path/data/fish.sas";




